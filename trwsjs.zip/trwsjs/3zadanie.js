const daysOfWeek = {
    ru: ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'],
    en: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    };
    
    console.log(daysOfWeek.ru[0]);
    console.log(daysOfWeek.en[2]);
